/*
 * Copyright (C) 2026  Behdad Esfahbod
 *
 *  This is part of HarfBuzz, a text shaping library.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN
 * IF THE COPYRIGHT HOLDER HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 *
 * THE COPYRIGHT HOLDER SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING,
 * BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE COPYRIGHT HOLDER HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */


/* Requires Shader Model 5.0+. */


/* Dilate a glyph vertex by half a pixel on screen.
 *
 * position:  object-space vertex position (modified in place)
 * texcoord:  em-space sample coordinates (modified in place)
 * normal:    object-space outward normal at this vertex
 * jac:       inverse of the 2x2 linear part of the em-to-object transform
 * m:         model-view-projection matrix
 * viewport:  viewport size in pixels
 */
void hb_gpu_dilate (inout float2 position, inout float2 texcoord,
                    float2 normal, float4 jac,
                    float4x4 m, float2 viewport)
{
  float2 n = normalize (normal);

  float4 clipPos = mul (m, float4 (position, 0.0, 1.0));
  float4 clipN   = mul (m, float4 (n, 0.0, 0.0));

  float s = clipPos.w;
  float t = clipN.w;

  float u = (s * clipN.x - t * clipPos.x) * viewport.x;
  float v = (s * clipN.y - t * clipPos.y) * viewport.y;

  float s2 = s * s;
  float st = s * t;
  float uv = u * u + v * v;

  float denom = uv - st * st;
  float d = abs (denom) > 1.0 / 16777216.0
          ? s2 * (st + sqrt (uv)) / denom
          : 0.0;

  float2 dPos = d * normal;
  position += dPos;
  texcoord += float2 (dot (dPos, jac.xy), dot (dPos, jac.zw));
}
