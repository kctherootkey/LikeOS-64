\" Example
.HU "macro"
