/* Copyright (c) 2007 Eric Scott Albright
 * Copyright (C) 2023-2026 Reuben Thomas
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include "config.h"
#include <stdio.h>
#include <UnitTest++/UnitTest++.h>
#include <glib.h>

#include "EnchantBrokerTestFixture.h"
#include "enchant.h"

EnchantProvider * EnchantBrokerTestFixture::mock_provider=NULL;
ConfigureHook EnchantBrokerTestFixture::userMockProviderConfiguration=NULL;
ConfigureHook EnchantBrokerTestFixture::userMockProvider2Configuration=NULL;


int main(){
#ifndef ENABLE_RELOCATABLE
  fprintf(stderr, "You must configure with --enable-relocatable to be able to run the tests\n");
  return 1;
#else
  enchant_set_prefix_dir(".");
  g_log_set_always_fatal(G_LOG_LEVEL_CRITICAL);
  return UnitTest::RunAllTests();
#endif
}
