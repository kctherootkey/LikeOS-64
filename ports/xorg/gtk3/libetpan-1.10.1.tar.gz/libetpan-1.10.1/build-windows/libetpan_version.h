/*
 * libEtPan! -- a mail stuff library
 *
 * Copyright (C) 2001 - 2003 - DINH Viet Hoa
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the libEtPan! project nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#ifndef LIBETPAN_VERSION_H

#define LIBETPAN_VERSION_H

#ifndef LIBETPAN_VERSION_MAJOR
#define LIBETPAN_VERSION_MAJOR 1
#endif

#ifndef LIBETPAN_VERSION_MINOR
#define LIBETPAN_VERSION_MINOR 10
#endif

#ifndef LIBETPAN_VERSION_MICRO
#define LIBETPAN_VERSION_MICRO 1
#endif

#ifndef LIBETPAN_REENTRANT
#if 1
#define LIBETPAN_REENTRANT 1
#endif

#ifndef LIBETPAN_API_CURRENT
#define LIBETPAN_API_CURRENT 26
#endif

#ifndef LIBETPAN_API_REVISION
#define LIBETPAN_API_REVISION 0
#endif

#ifndef LIBETPAN_API_COMPATIBILITY
#define LIBETPAN_API_COMPATIBILITY 26
#endif

#endif

int libetpan_get_version_major(void);
int libetpan_get_version_minor(void);
int libetpan_get_version_micro(void);

#endif
