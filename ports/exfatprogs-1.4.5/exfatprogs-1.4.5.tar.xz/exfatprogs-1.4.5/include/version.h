/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 *  Copyright (C) 2020 Namjae Jeon <linkinjeon@kernel.org>
 */

#ifndef _VERSION_H

#define EXFAT_PROGS_VERSION "1.4.5"
#define EXFAT_PROGS_RELEASE_DATE "2026-11-18"

#endif /* !_VERSION_H */
